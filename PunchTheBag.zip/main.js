document.addEventListener('DOMContentLoaded', () => {

  /* ==========================================================================
     REFERENCIAS AL DOM
     ========================================================================== */
  const enemySprite = document.getElementById('enemy-sprite');
  const ringWrapper = document.querySelector('.ring-wrapper');
  const enemyHealthBar = document.getElementById('enemy-health-bar');
  const playerHealthBar = document.getElementById('player-health-bar');
  const wordDisplay = document.getElementById('word-display');
  const wordInput = document.getElementById('word-input');
  const currentScoreEl = document.getElementById('current-score');
  const currentRoundEl = document.getElementById('current-round');
  const timerRing = document.getElementById('timer-ring-progress');

  const roundBanner = document.getElementById('round-banner');
  const roundBannerText = document.getElementById('round-banner-text');

  const startScreen = document.getElementById('start-screen');
  const startBtn = document.getElementById('start-btn');

  const defeatScreen = document.getElementById('defeat-screen');
  const defeatNameInput = document.getElementById('defeat-name-input');
  const defeatSubmitBtn = document.getElementById('defeat-submit-btn');
  const defeatReplayBtn = document.getElementById('defeat-replay-btn');

  const leaderboardBody = document.getElementById('leaderboard-body');

  /* ==========================================================================
     SPRITE DEL ENEMIGO (idle / attack)
     El atlas tiene 2 filas: fila 0 = idle, fila 1 = attack.
     "attack" no hace loop: se reproduce una vez y avisa con onComplete.
     ========================================================================== */
  const frameWidth = 64;
  const frameHeight = 140;
  const spriteAnimations = {
    idle:   { row: 0, startFrame: 4, frames: 2, speed: 220, loop: true },
    attack: { row: 1, startFrame: 4, frames: 3, speed: 80,  loop: false }
  };

  let spriteFrame = 0;
  let spriteInterval = null;

  function playEnemyAnimation(name, onComplete) {
    const anim = spriteAnimations[name];
    spriteFrame = 0;
    if (spriteInterval) clearInterval(spriteInterval);

    spriteInterval = setInterval(() => {
      const posX = (anim.startFrame + spriteFrame) * frameWidth;
      const posY = anim.row * frameHeight;
      enemySprite.style.backgroundPosition = `-${posX}px -${posY}px`;

      spriteFrame++;
      if (spriteFrame >= anim.frames) {
        if (anim.loop) {
          spriteFrame = 0;
        } else {
          clearInterval(spriteInterval);
          if (onComplete) onComplete();
        }
      }
    }, anim.speed);
  }

  /* ==========================================================================
     BANCO DE PALABRAS
     La API externa que usábamos (api-palabras-aleatorias) devuelve 404 y
     tampoco tiene cabecera CORS, así que es inusable desde el navegador.
     En su lugar usamos un banco local muy amplio, categorizado por
     dificultad: no depende de red, no puede fallar ni tener CORS.
     ========================================================================== */
  const wordBank = {
    facil: [
      'casa','perro','gato','sol','luna','agua','pan','flor','mesa','libro',
      'silla','mano','pie','ojo','boca','nariz','oreja','pelo','cielo','mar',
      'río','lago','monte','roca','arena','nube','lluvia','nieve','viento','fuego',
      'tierra','aire','luz','sombra','noche','día','hora','mes','año','hoy',
      'ayer','tarde','niño','niña','hombre','mujer','bebé','amigo','madre','padre',
      'hijo','hija','coche','tren','avión','barco','calle','plaza','parque','ciudad',
      'playa','bosque','campo','animal','pájaro','pez','león','tigre','oso','lobo',
      'zorro','conejo','ratón','vaca','cerdo','oveja','cabra','caballo','pollo','pato',
      'rana','abeja','hormiga','mosca','fruta','manzana','pera','uva','fresa','limón',
      'leche','queso','huevo','carne','arroz','sopa','dulce','café','vino','ropa',
      'camisa','falda','zapato','guante','bolso','reloj','anillo','gafas','lápiz','goma',
      'papel','mochila','clase','juego','pelota','baile','cine','arte','dibujo','foto',
      'mundo','tiempo','gente','lugar','parte','vida','cabeza','cuerpo','brazo','pierna',
      'dedo','diente','sangre','hueso','cama','puerta','techo','suelo','pared','patio',
      'garaje','baño','salón','tejado','chimenea','buzón','farola','acera','puente','torre',
      'iglesia','museo','tienda','banco','hospital','escuela','oficina','fábrica','granja','establo',
      'nido','cueva','isla','selva','valle','colina','volcán','estrella','planeta','trueno','rayo'
    ],
    media: [
      'jardín','montaña','ventana','escritorio','bicicleta','camino','nublado','pescado','cuaderno','profesor',
      'alumno','ordenador','teléfono','pantalla','teclado','internet','cumpleaños','pasaporte','maleta','piscina',
      'deporte','baloncesto','escalera','comedor','dormitorio','armario','cortina','alfombra','espejo','lámpara',
      'balcón','terraza','jardinero','panadero','carpintero','electricista','fontanero','mecánico','cantante','bailarín',
      'escritor','pintor','científico','ingeniero','arquitecto','abogado','médico','enfermero','bombero','policía',
      'soldado','marinero','piloto','astronauta','periodista','fotógrafo','director','actriz','músico','futbolista',
      'nadador','ciclista','corredor','agricultura','comercio','economía','política','historia','geografía','biología',
      'química','física','ecología','mecánica','medicina','farmacia','publicidad','mercado','vecindario','farmacéutico',
      'biblioteca','universidad','laboratorio','diccionario','calendario','desayuno','almuerzo','merienda','restaurante','camarero',
      'cocinero','ingrediente','receta','sabroso','delicioso','saludable','nutritivo','vitamina','proteína','alimento',
      'castillo','desierto','cascada','eclipse','arcoíris','huracán','tornado','terremoto','incendio','corazón',
      'pulmón','cerebro','estómago','panorama','horizonte','atardecer','amanecer'
    ],
    dificil: [
      'extraordinario','murciélago','ferrocarril','incomprensible','paralelepípedo','desafortunadamente','electroencefalograma','otorrinolaringólogo','anticonstitucional','desoxirribonucleico',
      'responsabilidad','característica','extraterrestre','contradictorio','internacionalización','constitucionalidad','desproporcionado','incuestionable','imprescindible','paradójicamente',
      'extraordinariamente','incompatibilidad','multidisciplinario','interdisciplinario','sobredimensionado','descontextualizado','electrocardiograma','deshidratación','subdesarrollado','infraestructura',
      'telecomunicaciones','videoconferencia','retroalimentación','reestructuración','descentralización','industrialización','comercialización','sobreexplotación','aprovechamiento','establecimiento',
      'reconocimiento','desconocimiento','agradecimiento','funcionamiento','planteamiento','procedimiento','acontecimiento','desenvolvimiento','envejecimiento','fortalecimiento',
      'restablecimiento','superpoblación','malentendido','incondicional','irresponsable','desobediencia','insatisfecho','inconformista','autosuficiente','autodidacta',
      'cortocircuito','contraataque','sobrecalentamiento','descompresión','hipersensibilidad','incompetencia','inexperiencia','desconfianza','desorientación','desmotivación',
      'indiferencia','impaciencia','intolerancia','desigualdad','discriminación','globalización','digitalización','automatización','personalización','especialización',
      'profesionalización','modernización','occidentalización','deforestación','contaminación','sostenibilidad','biodiversidad','urbanización','lingüísticamente','filosóficamente',
      'psicológicamente','sociológicamente','desproporcionadamente','incomprensiblemente'
    ]
  };

  function getDifficultyLevel() {
    if (state.round <= 2) return 'facil';
    if (state.round <= 5) return 'media';
    return 'dificil';
  }

  // Quita tildes/diéresis para comparar sin exigir que el jugador las escriba
  // (la palabra se sigue MOSTRANDO con tilde, solo la comparación es tolerante).
  // La ñ se deja intacta a propósito: no es "una n con tilde", es otra letra.
  const ACCENT_MAP = { 'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u', 'ü': 'u' };
  function normalizeWord(str) {
    return str.toLowerCase().split('').map(ch => ACCENT_MAP[ch] || ch).join('');
  }

  function pickWord() {
    const list = wordBank[getDifficultyLevel()];
    return list[Math.floor(Math.random() * list.length)];
  }

  /* ==========================================================================
     ESTADO DEL JUEGO
     ========================================================================== */
  const state = {
    playerHealth: 100,
    bossHealth: 100,
    score: 0,
    round: 1,          // sube cada vez que se derrota al boss (nunca termina la partida)
    wordsCorrect: 0,
    wordsTotal: 0,
    damageDealt: 0,
    startTime: null,
    currentWord: '',
    timeLeft: 0,
    timerId: null,
    gameOver: false
  };

  const RING_CIRCUMFERENCE = 628.3; // debe coincidir con el radio r=100 del SVG en el CSS

  /* ==========================================================================
     DIFICULTAD PROGRESIVA
     Todo escala con "round" (veces que se ha derrotado al boss), no con
     cada palabra suelta: derrotar al boss es lo que sube el nivel.
     ========================================================================== */
  function getMsPerLetter() {
    // Menos tiempo por letra cuantas más rondas se han superado (mínimo 180ms/letra)
    return Math.max(180, 480 - (state.round - 1) * 30);
  }

  function getTimeLimit() {
    // El tiempo total depende de cuántas letras tiene la palabra actual
    const letters = state.currentWord.length || 1;
    return Math.max(1000, Math.round(letters * getMsPerLetter()));
  }

  function getPlayerDamage() {
    // Más daño por fallo cuantas más rondas se han superado (máximo 35)
    return Math.min(35, 10 + (state.round - 1) * 3);
  }

  /* ==========================================================================
     PALABRA ACTUAL
     ========================================================================== */
  function pickNewWord() {
    state.currentWord = pickWord();
    wordDisplay.textContent = state.currentWord;
    wordInput.value = '';
    wordInput.focus();
    startTimer();
  }

  /* ==========================================================================
     TEMPORIZADOR CIRCULAR
     ========================================================================== */
  function startTimer() {
    clearInterval(state.timerId);
    state.timeLeft = getTimeLimit();
    const total = state.timeLeft;
    updateRing(1); // círculo lleno al empezar

    const tickMs = 50;
    state.timerId = setInterval(() => {
      state.timeLeft -= tickMs;
      updateRing(Math.max(0, state.timeLeft / total));

      if (state.timeLeft <= 0) {
        clearInterval(state.timerId);
        handleFail();
      }
    }, tickMs);
  }

  function updateRing(fraction) {
    timerRing.style.strokeDashoffset = RING_CIRCUMFERENCE * (1 - fraction);
    timerRing.style.stroke = fraction > 0.3 ? 'var(--accent-gold)' : 'var(--accent-red)';
  }

  /* ==========================================================================
     ACIERTO: el boss recibe daño.
     Si su vida llega a 0, NO termina la partida: sube de ronda y se resetea.
     ========================================================================== */
  function handleCorrect() {
    clearInterval(state.timerId);
    state.wordsCorrect++;
    state.wordsTotal++;

    const damage = 10;
    state.damageDealt += damage;
    state.bossHealth = Math.max(0, state.bossHealth - damage);
    state.score += damage * 10 + 5;

    updateHealthBar(enemyHealthBar, state.bossHealth);
    currentScoreEl.textContent = state.score;
    flashHit(ringWrapper); // feedback visual de impacto sobre el boss

    if (state.bossHealth <= 0) {
      handleBossDefeated();
      return;
    }
    pickNewWord();
  }

  function handleBossDefeated() {
    state.round++;
    state.bossHealth = 100;
    updateHealthBar(enemyHealthBar, 100);
    currentRoundEl.textContent = state.round;
    showRoundBanner(`¡Boss derrotado! Ronda ${state.round}`);
    pickNewWord(); // el juego sigue sin pausa
  }

  function showRoundBanner(text) {
    roundBannerText.textContent = text;
    roundBanner.classList.add('show');
    clearTimeout(showRoundBanner._t);
    showRoundBanner._t = setTimeout(() => roundBanner.classList.remove('show'), 1800);
  }

  /* ==========================================================================
     FALLO (palabra mal escrita o tiempo agotado): el jugador recibe daño.
     La animación de ataque del boss SOLO se reproduce aquí.
     La partida termina únicamente cuando la vida del jugador llega a 0.
     ========================================================================== */
  function handleFail() {
    state.wordsTotal++;

    const damage = getPlayerDamage();
    state.playerHealth = Math.max(0, state.playerHealth - damage);
    updateHealthBar(playerHealthBar, state.playerHealth);

    playEnemyAnimation('attack', () => playEnemyAnimation('idle'));
    shakeScreen();

    if (state.playerHealth <= 0) {
      endGame();
      return;
    }
    pickNewWord();
  }

  function updateHealthBar(el, value) {
    el.style.width = value + '%';
    if (value > 50) el.style.backgroundColor = 'var(--health-ok)';
    else if (value > 20) el.style.backgroundColor = 'var(--health-mid)';
    else el.style.backgroundColor = 'var(--health-low)';
  }

  function flashHit(el) {
    el.classList.add('hit-flash');
    setTimeout(() => el.classList.remove('hit-flash'), 200);
  }

  function shakeScreen() {
    document.body.classList.add('shake');
    setTimeout(() => document.body.classList.remove('shake'), 300);
  }

  /* ==========================================================================
     INPUT DEL JUGADOR
     Se comprueba en cada pulsación: si coincide con la palabra, acierto inmediato.
     ========================================================================== */
  wordInput.addEventListener('input', () => {
    if (state.gameOver) return;
    if (normalizeWord(wordInput.value) === normalizeWord(state.currentWord)) {
      handleCorrect();
    }
  });

  /* ==========================================================================
     FIN DE PARTIDA (solo ocurre al morir el jugador)
     ========================================================================== */
  function getAccuracy() {
    return state.wordsTotal > 0 ? Math.round((state.wordsCorrect / state.wordsTotal) * 100) : 0;
  }

  function getElapsedSeconds() {
    return Math.round((Date.now() - state.startTime) / 1000);
  }

  function endGame() {
    state.gameOver = true;
    clearInterval(state.timerId);
    wordInput.disabled = true;

    document.getElementById('defeat-round').textContent = state.round;
    document.getElementById('defeat-damage').textContent = state.damageDealt;
    document.getElementById('defeat-words').textContent = state.wordsCorrect;
    document.getElementById('defeat-accuracy').textContent = getAccuracy();
    document.getElementById('defeat-time').textContent = getElapsedSeconds() + 's';
    document.getElementById('defeat-final-score').textContent = state.score;

    defeatScreen.style.display = 'flex';
  }

  /* ==========================================================================
     LEADERBOARD
     Vive solo en memoria: un simple array durante esta visita a la página.
     Al recargar o cerrar la pestaña se pierde (a propósito, no usa localStorage
     ni ningún servidor).
     ========================================================================== */
  let leaderboardEntries = [];

  function getLeaderboard() {
    return leaderboardEntries;
  }

  function saveScore(name) {
    leaderboardEntries.push({
      name: name || 'Anónimo',
      score: state.score,
      date: new Date().toLocaleDateString('es-ES'),
      time: getElapsedSeconds(),
      accuracy: getAccuracy()
    });
    leaderboardEntries.sort((a, b) => b.score - a.score);
    leaderboardEntries = leaderboardEntries.slice(0, 20);
    renderLeaderboard();
  }

  function renderLeaderboard() {
    const entries = getLeaderboard();
    leaderboardBody.innerHTML = '';
    entries.slice(0, 10).forEach((entry, i) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${i + 1}</td><td>${entry.name}</td><td>${entry.score}</td>`;
      leaderboardBody.appendChild(tr);
    });
  }

  /* ==========================================================================
     BOTONES DE LA PANTALLA DE DERROTA
     El botón de guardar se deshabilita tras usarse una vez, para no poder
     guardar la misma puntuación varias veces.
     ========================================================================== */
  defeatSubmitBtn.addEventListener('click', () => {
    if (defeatSubmitBtn.disabled) return;
    saveScore(defeatNameInput.value.trim());
    defeatSubmitBtn.disabled = true;
    defeatSubmitBtn.textContent = 'Guardado ✓';
    defeatNameInput.disabled = true;
  });

  defeatReplayBtn.addEventListener('click', resetGame);

  /* ==========================================================================
     PANTALLA DE INICIO
     El juego no arranca hasta que el jugador pulsa "Empezar".
     ========================================================================== */
  startBtn.addEventListener('click', () => {
    startScreen.style.display = 'none';
    resetGame();
  });

  /* ==========================================================================
     REINICIAR / ARRANCAR PARTIDA
     ========================================================================== */
  function resetGame() {
    state.playerHealth = 100;
    state.bossHealth = 100;
    state.score = 0;
    state.round = 1;
    state.wordsCorrect = 0;
    state.wordsTotal = 0;
    state.damageDealt = 0;
    state.gameOver = false;
    state.startTime = Date.now();

    updateHealthBar(enemyHealthBar, 100);
    updateHealthBar(playerHealthBar, 100);
    currentScoreEl.textContent = 0;
    currentRoundEl.textContent = 1;
    wordInput.disabled = false;

    defeatScreen.style.display = 'none';
    defeatSubmitBtn.disabled = false;
    defeatSubmitBtn.textContent = 'Guardar puntuación';
    defeatNameInput.disabled = false;
    defeatNameInput.value = '';

    playEnemyAnimation('idle');
    pickNewWord();
  }

  // El juego no arranca solo: espera al click en "Empezar" (ver más arriba).
  // Solo pintamos el leaderboard, que tiene sentido verlo antes de jugar.
  renderLeaderboard();
});
